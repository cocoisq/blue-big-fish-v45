package com.cocoisq.bluebigfish

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("blue_big_fish_counts", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(237, 243, 255)
        window.navigationBarColor = android.graphics.Color.rgb(220, 232, 255)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(237, 243, 255))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(GameBridge(), "AndroidBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun refreshDate() {
        val today = todayKey()
        if (prefs.getString("date", "") != today) {
            prefs.edit().putString("date", today).putInt("today", 0).apply()
        }
    }

    inner class GameBridge {
        @JavascriptInterface
        fun getCounts(): String {
            refreshDate()
            return JSONObject()
                .put("today", prefs.getInt("today", 0))
                .put("total", prefs.getLong("total", 0L))
                .toString()
        }

        @JavascriptInterface
        fun recordTap(): String {
            refreshDate()
            val today = prefs.getInt("today", 0) + 1
            val total = prefs.getLong("total", 0L) + 1L
            prefs.edit().putInt("today", today).putLong("total", total).apply()
            return JSONObject().put("today", today).put("total", total).toString()
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
