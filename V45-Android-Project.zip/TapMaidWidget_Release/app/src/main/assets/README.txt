藍色大肥魚｜雙曲目節奏版 V26

內容：
- index.html：遊戲本體，含更改音樂／更改難度設定
- rhythm_music.mp3：朋友的酒（原有曲目）
- rhythm_music_2.mp3：八千里路明月照（新增曲目）
- manifest.webmanifest：加入手機主畫面的設定
- service-worker.js：離線快取（V26）
- icons/：主畫面圖示

功能：
- 預設歌曲為「朋友的酒」
- 可切換「八千里路明月照」
- 兩首歌曲使用各自獨立的節拍時間表與觸發間隔
- 難度保留：困難、一般、簡單、極為簡單
- 音樂與難度選擇會保存在裝置上

部署需求：將整個資料夾內容放在 HTTPS 網站空間，建議使用 GitHub Pages。
Android APK：若使用原本的 Android WebView 封裝專案，請將本版網頁檔案完整放入其 assets/www（或原專案指定的網頁資源資料夾），再重新編譯 APK。
iPhone：使用 Safari 開啟網站 → 分享 → 加入主畫面。

注意：本 ZIP 是完整網頁遊戲專案，不是已簽署的 APK。Android 原生桌面小工具不包含在網頁版內。

V26: Active rhythm now checks both beat alignment and the interval between consecutive taps; added Very Hard mode with a 22 ms tolerance.


V26 更新：
- 修正歌曲播放期間快速連點仍不會中斷的問題。
- 播放期間每次點擊都同時檢查歌曲節拍偏差與相鄰點擊間隔；太快、太慢或落拍都會立即停止歌曲。
- 新增「極為困難」：起始節奏與播放中的每次點擊容許誤差均為 22 ms，任一點擊超出即停止。
- 原有四種難度保留，兩首歌仍使用各自的節拍資料。

V27 設定介面：更改音樂/更改難度分頁只顯示對應選項；點選歌曲或難度立即套用並自動關閉設定視窗；移除返回與完成按鈕。

V28：設定主選單、音樂選擇、難度選擇三個畫面互斥顯示；音樂頁只顯示兩首歌，難度頁只顯示五種難度。修正 Android WebView 下多個設定區塊同時顯示的問題。
